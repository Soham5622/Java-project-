package com.soham.rag.service;

import com.soham.rag.model.SourceChunk;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RagService {
    private final DocumentStore store;
    private final OllamaService ollama;

    public RagService(DocumentStore store, OllamaService ollama) {
        this.store = store;
        this.ollama = ollama;
    }

    public Answer ask(String question) throws IOException, InterruptedException {
        if (question == null || question.isBlank()) {
            throw new IllegalArgumentException("Please enter a question.");
        }
        List<SourceChunk> sources = store.search(question, 4);
        if (sources.isEmpty()) {
            return new Answer("I couldn't find a relevant passage in the uploaded documents. Try uploading a PDF or asking a question using its wording.", List.of());
        }

        String context = sources.stream()
                .map(s -> "[Source: " + s.documentName() + ", chunk " + s.chunkNumber() + "]\n" + s.text())
                .collect(Collectors.joining("\n\n---\n\n"));

        String prompt = """
                You are College Notes AI, a helpful study assistant.
                Answer the user's question using ONLY the context below.
                If the context does not contain the answer, say that the uploaded documents do not provide enough information.
                Do not invent facts. Keep the answer clear and student-friendly.

                CONTEXT:
                %s

                QUESTION:
                %s

                ANSWER:
                """.formatted(context, question);

        String answer = ollama.generate(prompt).trim();
        return new Answer(answer, sources);
    }

    public record Answer(String answer, List<SourceChunk> sources) {}
}

package com.soham.rag.controller;

import com.soham.rag.model.SourceChunk;
import com.soham.rag.service.DocumentStore;
import com.soham.rag.service.PdfService;
import com.soham.rag.service.RagService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RagController {
    private final PdfService pdfService;
    private final DocumentStore documentStore;
    private final RagService ragService;

    public RagController(PdfService pdfService, DocumentStore documentStore, RagService ragService) {
        this.pdfService = pdfService;
        this.documentStore = documentStore;
        this.ragService = ragService;
    }

    @PostMapping(value = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file) {
        try {
            int chunks = pdfService.ingest(file);
            return Map.of("message", "PDF processed successfully.", "chunksAdded", chunks,
                    "totalChunks", documentStore.documentChunkCount());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Could not read this PDF file.");
        }
    }

    @PostMapping("/ask")
    public RagService.Answer ask(@RequestBody AskRequest request) {
        try {
            return ragService.ask(request.question());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Could not contact Ollama. Start Ollama and download the configured model first.");
        }
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of("status", "running", "storedChunks", documentStore.documentChunkCount());
    }

    @DeleteMapping("/documents")
    public Map<String, String> clearDocuments() {
        documentStore.clear();
        return Map.of("message", "All document chunks cleared.");
    }

    public record AskRequest(@NotBlank String question) {}
}

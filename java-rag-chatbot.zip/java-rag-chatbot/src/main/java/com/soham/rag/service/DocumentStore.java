package com.soham.rag.service;

import com.soham.rag.model.SourceChunk;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class DocumentStore {
    private final List<SourceChunk> chunks = new ArrayList<>();
    private static final Pattern NON_WORD = Pattern.compile("[^a-zA-Z0-9]+");

    public synchronized int addDocument(String documentName, String text) {
        String cleaned = text.replaceAll("\\s+", " ").trim();
        if (cleaned.isBlank()) return 0;

        int chunkSize = 900;
        int overlap = 150;
        int added = 0;
        for (int start = 0, number = 1; start < cleaned.length(); start += (chunkSize - overlap), number++) {
            int end = Math.min(cleaned.length(), start + chunkSize);
            String chunk = cleaned.substring(start, end).trim();
            if (!chunk.isBlank()) {
                chunks.add(new SourceChunk(documentName, number, chunk));
                added++;
            }
            if (end == cleaned.length()) break;
        }
        return added;
    }

    public synchronized List<SourceChunk> search(String question, int limit) {
        Set<String> terms = tokenize(question);
        if (terms.isEmpty()) return List.of();

        return chunks.stream()
                .map(chunk -> new ScoredChunk(chunk, score(chunk.text(), terms)))
                .filter(scored -> scored.score() > 0)
                .sorted(Comparator.comparingInt(ScoredChunk::score).reversed())
                .limit(limit)
                .map(ScoredChunk::chunk)
                .collect(Collectors.toList());
    }

    public synchronized int documentChunkCount() {
        return chunks.size();
    }

    public synchronized void clear() {
        chunks.clear();
    }

    private int score(String text, Set<String> terms) {
        Set<String> words = tokenize(text);
        int score = 0;
        for (String term : terms) {
            if (words.contains(term)) score += 2;
            else if (text.toLowerCase(Locale.ROOT).contains(term)) score += 1;
        }
        return score;
    }

    private Set<String> tokenize(String value) {
        return NON_WORD.splitAsStream(value.toLowerCase(Locale.ROOT))
                .filter(token -> token.length() > 2)
                .collect(Collectors.toSet());
    }

    private record ScoredChunk(SourceChunk chunk, int score) {}
}

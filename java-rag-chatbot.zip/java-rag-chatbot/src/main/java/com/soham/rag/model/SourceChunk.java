package com.soham.rag.model;

public record SourceChunk(String documentName, int chunkNumber, String text) {}

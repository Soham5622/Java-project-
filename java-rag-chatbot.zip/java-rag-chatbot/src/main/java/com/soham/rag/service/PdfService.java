package com.soham.rag.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class PdfService {
    private final DocumentStore documentStore;

    public PdfService(DocumentStore documentStore) {
        this.documentStore = documentStore;
    }

    public int ingest(MultipartFile file) throws IOException {
        if (file.isEmpty()) throw new IllegalArgumentException("The uploaded file is empty.");
        String name = file.getOriginalFilename() == null ? "uploaded.pdf" : file.getOriginalFilename();
        if (!name.toLowerCase().endsWith(".pdf")) {
            throw new IllegalArgumentException("Please upload a PDF file.");
        }

        try (PDDocument document = Loader.loadPDF(file.getBytes())) {
            String text = new PDFTextStripper().getText(document);
            if (text == null || text.isBlank()) {
                throw new IllegalArgumentException("No readable text was found. Scanned PDFs need OCR first.");
            }
            return documentStore.addDocument(name, text);
        }
    }
}

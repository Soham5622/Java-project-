# College Notes AI — Java RAG Chatbot

A beginner-friendly Retrieval-Augmented Generation (RAG) web application built primarily in Java. Upload text-based PDF notes, ask a question, retrieve relevant passages, and generate an answer using a local language model through Ollama.

## Features

- PDF upload and text extraction with Apache PDFBox
- Text chunking with overlap
- Simple lexical retrieval to find relevant chunks
- Answer generation through Ollama
- Source passages shown with each answer
- Web interface included
- REST API endpoints
- No paid model API key required when running Ollama locally

## Technology

- Java 17+
- Spring Boot 3.4.3
- Maven
- Apache PDFBox 3
- Ollama (local LLM)
- HTML, CSS and JavaScript

## Requirements

1. Install Java JDK 17 or later.
2. Install Maven.
3. Install Ollama from https://ollama.com/download.
4. Download a model. Example:

```bash
ollama pull llama3.2
```

Keep Ollama running. The default URL is `http://localhost:11434`.

## Run the application

From the project folder:

```bash
mvn spring-boot:run
```

Open http://localhost:8080 in your browser.

If you use a different Ollama model:

**Windows PowerShell**
```powershell
$env:OLLAMA_MODEL="llama3.2"
mvn spring-boot:run
```

**macOS/Linux**
```bash
OLLAMA_MODEL=llama3.2 mvn spring-boot:run
```

## How to use

1. Open the website.
2. Select a text-based PDF file and click **Upload PDF**.
3. Enter a question that relates to the PDF.
4. Click **Ask AI**.
5. Read the answer and check the retrieved source passages.

Uploaded document chunks are held in memory. Restarting the application clears them. This starter project does not provide permanent storage or user authentication.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/api/documents` | Upload a PDF as multipart field `file` |
| `POST` | `/api/ask` | Ask a question; JSON body: `{"question":"What is..."}` |
| `GET` | `/api/status` | Check app status and number of stored chunks |
| `DELETE` | `/api/documents` | Clear stored chunks |

## RAG workflow

1. PDFBox extracts text from the uploaded PDF.
2. Text is divided into overlapping chunks.
3. The document store ranks chunks using query-term overlap.
4. The top matching passages are sent to Ollama with the question.
5. The model generates an answer based on the supplied context.
6. The UI displays the answer and retrieved source passages.

## Important limitation

This is a learning/portfolio starter project. Retrieval currently uses keyword-based scoring, not vector embeddings. It demonstrates the RAG pipeline, but semantic retrieval can be improved by adding an embedding model and a vector database (for example, pgvector or Chroma). Answers can still be incorrect; verify important information against the source documents. Scanned/image-only PDFs require OCR.

## GitHub upload

Create a new empty repository named `java-rag-chatbot` on GitHub, then run these commands in this folder:

```bash
git init
git add .
git commit -m "Initial commit: Java RAG chatbot"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/java-rag-chatbot.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not commit private keys, passwords, or confidential documents.

## Suggested future improvements

- Embeddings and semantic vector search
- Multiple document collections and document deletion
- Persistent vector storage
- Chat history
- OCR for scanned PDFs
- Unit and integration tests
- Docker setup and deployment
